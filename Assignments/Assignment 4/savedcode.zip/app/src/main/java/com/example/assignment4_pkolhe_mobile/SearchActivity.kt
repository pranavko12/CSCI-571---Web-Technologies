package com.example.assignment4_pkolhe_mobile

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient
import org.json.JSONObject
import java.io.IOException

class SearchActivity : AppCompatActivity() {
    private lateinit var searchInput: EditText
    private lateinit var suggestionsList: ListView
    private lateinit var backButton: ImageButton
    private lateinit var suggestionsAdapter: ArrayAdapter<String>
    private lateinit var placesClient: PlacesClient

    private val suggestions = mutableListOf<String>()
    private val TAG = "SearchActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        // Initialize Places API
        if (!Places.isInitialized()) {
            Places.initialize(applicationContext, "AIzaSyBJu5-rCtn-37xsclF-73p830YSb5z259c")
        }
        placesClient = Places.createClient(this)

        // Initialize views
        searchInput = findViewById(R.id.search_input)
        suggestionsList = findViewById(R.id.suggestions_list)
        backButton = findViewById(R.id.back_button)

        // Initialize Adapter for suggestions
        suggestionsAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, suggestions)
        suggestionsList.adapter = suggestionsAdapter

        // Back button functionality
        backButton.setOnClickListener {
            finish()
        }

        // Add TextWatcher to handle input
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!s.isNullOrEmpty()) {
                    fetchSuggestions(s.toString())
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Handle suggestion clicks
        suggestionsList.setOnItemClickListener { _, _, position, _ ->
            val selectedCity = suggestions[position]
            fetchCityCoordinates(selectedCity)
        }
    }

    private fun fetchSuggestions(query: String) {
        val request = FindAutocompletePredictionsRequest.builder()
            .setQuery(query)
            .build()

        placesClient.findAutocompletePredictions(request).addOnSuccessListener { response ->
            suggestions.clear()
            for (prediction in response.autocompletePredictions) {
                // Filter predictions containing "locality" or city-related keywords
                suggestions.add(prediction.getPrimaryText(null).toString())
            }
            suggestionsAdapter.notifyDataSetChanged()
        }.addOnFailureListener { exception ->
            Log.e(TAG, "Error fetching autocomplete suggestions: ${exception.message}")
        }
    }



    private fun fetchCityCoordinates(city: String) {
        val geocodeUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=${city.replace(" ", "+")}&key=AIzaSyBJu5-rCtn-37xsclF-73p830YSb5z259c"
        val client = okhttp3.OkHttpClient()
        val request = okhttp3.Request.Builder().url(geocodeUrl).build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                Log.e(TAG, "Error fetching geocode data: ${e.message}")
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.body?.let { responseBody ->
                    val json = JSONObject(responseBody.string())
                    val results = json.getJSONArray("results")
                    if (results.length() > 0) {
                        val location = results.getJSONObject(0).getJSONObject("geometry")
                            .getJSONObject("location")
                        val lat = location.getDouble("lat")
                        val lng = location.getDouble("lng")
                        val city = results.getJSONObject(0).getString("formatted_address")
                        // Redirect to HomeActivity with city details

                        val intent = when (city) {
                            "Los Angeles" -> Intent(this@SearchActivity, HomeActivity::class.java)
                            "Las Vegas" -> Intent(this@SearchActivity, H2::class.java)
                            "Kansas" -> Intent(this@SearchActivity, H3::class.java)
                            else -> Intent(this@SearchActivity, HomeActivity::class.java)
                        }.apply {
                            putExtra("city_name", city)
                            putExtra("lat", lat)
                            putExtra("lng", lng)
                        }
                        startActivity(intent)
                    }
                }
            }
        })
    }
}