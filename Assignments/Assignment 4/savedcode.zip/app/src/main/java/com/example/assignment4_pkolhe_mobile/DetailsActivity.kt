package com.example.assignment4_pkolhe_mobile

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView

class DetailsActivity : AppCompatActivity() {

    private lateinit var backButton: ImageButton
    private lateinit var tweetButton: ImageButton
    private lateinit var cityNameTextView: TextView
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        // Initialize views
        backButton = findViewById(R.id.back_button)
        tweetButton = findViewById(R.id.twitterButton)
        cityNameTextView = findViewById(R.id.city_name)
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)

        // Get data passed from HomeActivity
        val cityName = intent.getStringExtra("city_name") ?: "Unknown City"
        val temperature = intent.getStringExtra("temperature") ?: "0°F"
        val pressure = intent.getStringExtra("pressure") ?: "0 inHg"
        val weatherSummary = intent.getStringExtra("weather_summary") ?: "N/A"
        val humidity = intent.getStringExtra("humidity") ?: "0%"
        val windSpeed = intent.getStringExtra("wind_speed") ?: "0 mph"
        val visibility = intent.getStringExtra("visibility") ?: "0 mi"
        val cloudCover = intent.getStringExtra("cloud_cover") ?: "0%"

        val weatherDetails = Bundle().apply {
            putString("temperature", temperature)
            putString("pressure", pressure)
            putString("weather_summary", weatherSummary)
            putString("humidity", humidity)
            putString("wind_speed", windSpeed)
            putString("visibility", visibility)
            putString("cloud_cover", cloudCover)
        }

        // Set city name in toolbar
        cityNameTextView.text = cityName

        // Set up ViewPager and Tabs
        val detailsPagerAdapter = DetailsPagerAdapter(this, cityName, weatherDetails)
        viewPager.adapter = detailsPagerAdapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            val tabView = LayoutInflater.from(this).inflate(R.layout.tab_layout, null)
            val tabIcon = tabView.findViewById<ImageView>(R.id.tab_icon)
            val tabTitle = tabView.findViewById<TextView>(R.id.tab_title)

            when (position) {
                0 -> {
                    tabIcon.setImageResource(R.drawable.today_icon)
                    tabTitle.text = "TODAY"
                }
                1 -> {
                    tabIcon.setImageResource(R.drawable.weekly_icon)
                    tabTitle.text = "WEEKLY"
                }
                2 -> {
                    tabIcon.setImageResource(R.drawable.weather_data_icon)
                    tabTitle.text = "WEATHER DATA"
                }
            }

            tab.customView = tabView
        }.attach()


        // Back Button Action
        backButton.setOnClickListener {
            finish()
        }


        tweetButton.setOnClickListener {
            // Construct the tweet content in the desired format
//            val tweetContent = "Check Out $cityName’s Weather! It is $temperature°F! #CSCI571WeatherSearch"
//
//            // Encode the tweet content for URL safety
//            tweetButton = findViewById(R.id.tweet_button)
//            val twitterUrl = "https://twitter.com/intent/tweet?text=${Uri.encode(tweetContent)}"
//
//            // Create an intent to open the Twitter sharing URL
//            val tweetIntent = Intent(Intent.ACTION_VIEW, Uri.parse(twitterUrl))
//
//            // Check if there is an app available to handle the intent
//            if (tweetIntent.resolveActivity(packageManager) != null) {
//                startActivity(tweetIntent)
//            } else {
//                // Display a message if no app can handle the intent
//                Toast.makeText(this, "No application can handle this action", Toast.LENGTH_SHORT).show()
//            }

            val city = "Los Angeles" // Replace with actual city dynamically
            val temperature = "75°F" // Replace with actual temperature dynamically
            val hashTag = "#CSCI571WeatherSearch"
            val tweetText = "Check Out $city's Weather! It is $temperature! $hashTag"

            val twitterButton = findViewById<Button>(R.id.twitterButton)
            twitterButton.setOnClickListener {
                val tweetUrl = "https://twitter.com/intent/tweet?text=${Uri.encode(tweetText)}"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tweetUrl))
                startActivity(intent)
            }
        }
    }
}
