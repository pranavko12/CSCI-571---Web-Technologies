package com.example.assignment4_pkolhe_mobile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.highsoft.highcharts.common.hichartsclasses.*
import com.highsoft.highcharts.core.HIChartView
import java.text.SimpleDateFormat
import java.util.*

class WeeklyFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_weekly, container, false)

        // Find the Highcharts chart view
        val chartView = view.findViewById<HIChartView>(R.id.weekly_chart)

        // Retrieve data from arguments
        val weatherDetails = arguments
        val tempHighs = weatherDetails?.getIntegerArrayList("temp_high_list") ?: arrayListOf()
        val tempLows = weatherDetails?.getIntegerArrayList("temp_low_list") ?: arrayListOf()
        val dates = weatherDetails?.getStringArrayList("dates_list")?.map { formatDate(it) } ?: arrayListOf()

        // Set up the chart options
        val options = createChartOptions(dates, tempHighs, tempLows)
        chartView.options = options

        return view
    }

    fun createChartOptions(
        dates: List<String>,
        tempHighs: List<Int>,
        tempLows: List<Int>
    ): HIOptions {
        // Create Chart Options
        val options = HIOptions()

        // Set Chart Type
        val chart = HIChart()
        chart.type = "arearange"
        options.chart = chart

        // Set Title
        val title = HITitle()
        title.text = "Temperature variation by day"
        options.title = title

        // Set X-axis categories
        val xAxis = HIXAxis()
        xAxis.categories = ArrayList(dates) // Use extracted dates here
        options.xAxis = arrayListOf(xAxis)

        // Set Y-axis Title
        val yAxis = HIYAxis()
        val yAxisTitle = HITitle()
        yAxisTitle.text = "Values"
        yAxis.title = yAxisTitle
        options.yAxis = arrayListOf(yAxis)

        // Set Data Series
        val series = HIArearange()
        series.name = "Temperature"
        series.data = ArrayList(tempHighs.mapIndexed { index, high ->
            arrayListOf(tempLows[index].toDouble(), high.toDouble())
        })
        options.series = arrayListOf(series)

        return options
    }


    private fun formatDate(inputDate: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val outputFormat = SimpleDateFormat("d. MMM", Locale.US)
            val date = inputFormat.parse(inputDate)
            outputFormat.format(date ?: inputDate)
        } catch (e: Exception) {
            e.printStackTrace()
            inputDate
        }
    }

    companion object {
        fun newInstance(weatherDetails: Bundle): WeeklyFragment {
            val fragment = WeeklyFragment()
            fragment.arguments = weatherDetails
            return fragment
        }
    }
}
