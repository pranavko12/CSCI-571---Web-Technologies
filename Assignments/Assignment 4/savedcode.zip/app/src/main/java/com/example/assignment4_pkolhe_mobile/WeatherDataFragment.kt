package com.example.assignment4_pkolhe_mobile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class WeatherDataFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_weather_data, container, false)
        val weatherDataTextView = view.findViewById<TextView>(R.id.weather_data_text)
        val city = arguments?.getString("city") ?: "Unknown City"
        weatherDataTextView.text = "Weather data for $city"
        return view
    }

    companion object {
        fun newInstance(city: String): WeatherDataFragment {
            val fragment = WeatherDataFragment()
            val bundle = Bundle().apply {
                putString("city", city)
            }
            fragment.arguments = bundle
            return fragment
        }
    }
}
